ReadMe 1.0

Today, I Am Jackaboy

Dear user / player,

If you are reading this, you most likely stumbled upon 
an error or a crash in the game.

-Unzip both the .jar and .bat file that are present in 
this very .zip file.

-run the Launcher.bat by double clicking on it.
let the game run and play as you would the other game.

(if you want to keep your save files, put the .bat and .jar
in the same directory as your .exe file (if you had any))

-when the game crashes, Alt-Tab out of the game, to the CMD 
window, and rightclick the words. Select 'Select All'. Press 
Enter when all is highlighted.
Congratulations, you have now copied all this information !

-visit a site like pastebin.com, and use either right mouse click
to paste the content you just copied in the previous step, 
or use Ctrl - V .

-Create a new paste, and send that link to our dev's twitter :

https://twitter.com/AbsolemJackDaw
@AbsolemJackDaw

yes, sorry, he only has a twitter :/

try to describe briefly what you were doing and what happened.
He'll answer asap, and make a fix for it !


that was it ! 
thank you for aiding in the developpement of our first fan-made game !


